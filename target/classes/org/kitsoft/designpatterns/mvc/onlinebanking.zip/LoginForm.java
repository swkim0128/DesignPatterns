package org.kitsoft.designpatterns.mvc.onlinebanking;

import javax.swing.*;

public class LoginForm {
    private JButton button1;
    private JTextArea textArea1;
    private JTextArea textArea2;
    private JTextField textField1;
    private JTextField textField2;
}
