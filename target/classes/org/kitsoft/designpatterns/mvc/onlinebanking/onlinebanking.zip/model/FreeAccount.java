﻿package org.kitsoft.designpatterns.mvc.onlinebanking.model;

public class FreeAccount extends Account
{
	public FreeAccount()
	{
		withdrawMethod = new FreeWithdraw();
		calculateInterestMethod = new FreeCalculateInterest();
	}
}