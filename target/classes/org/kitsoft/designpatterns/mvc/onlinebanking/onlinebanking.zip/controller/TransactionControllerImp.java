package org.kitsoft.designpatterns.mvc.onlinebanking.controller;

public interface TransactionControllerImp {
	public void execute();
}
