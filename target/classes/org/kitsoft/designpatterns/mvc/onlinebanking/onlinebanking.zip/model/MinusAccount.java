﻿package org.kitsoft.designpatterns.mvc.onlinebanking.model;

public class MinusAccount extends Account
{
	int creditLimit;
	
	public MinusAccount(int creditLimit)
	{
		this.creditLimit = creditLimit;
		withdrawMethod = new MinusWithdraw(creditLimit);
		calculateInterestMethod = new MinusCalculateInterest();
	}
}
