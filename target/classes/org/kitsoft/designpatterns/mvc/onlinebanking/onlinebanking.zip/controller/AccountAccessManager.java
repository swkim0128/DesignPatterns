package org.kitsoft.designpatterns.mvc.onlinebanking.controller;

import org.kitsoft.designpatterns.mvc.onlinebanking.model.FileIOHandler;

public class AccountAccessManager {
	private FileIOHandler io;
	private Object ojbect;
	
	public AccountAccessManager(Object object) {
		io = new FileIOHandler();
		this.ojbect = object;
	}
	
	public void deposit() {
		
	}
	
	public void withdraw() {
		
	}
	
	public void inquireBalance() {
		
	}
	
	public void inquireTransactionInfo() {
		
	}
	
	public void transferAccount() {
		
	}
}
