﻿package org.kitsoft.designpatterns.mvc.onlinebanking.model;

import java.io.Serializable;
import java.util.ArrayList;

import org.kitsoft.designpatterns.mvc.onlinebanking.controller.AccountObserver;
import org.kitsoft.designpatterns.mvc.onlinebanking.controller.AccountSubject;

public class Account implements Serializable, AccountSubject
{
	private String AccountNum;
	protected int balance;
	protected CalculateInterestMethod calculateInterestMethod;
	protected WithdrawMethod withdrawMethod;
	
	protected ArrayList<TradeLog> tradeLogs; 
	private ArrayList<AccountObserver> observers;
	
	public Account()
	{
		tradeLogs = new ArrayList<TradeLog>();
	}
	
	public void registerObserver(AccountObserver o) {
		observers.add(o);
	}
	public void removeObserver(AccountObserver o) {
		observers.remove(o);
	}
	public void notifyObserver() {
		for(AccountObserver o : observers) {
			o.update();
		}
	}
	public void setAccount(Account a) {
		balance = a.getBalance();
		notifyObserver();
	}
	
	public int getBalance()
	{
		return balance;
	}
	
	public void deposit(int amount)
	{
		balance += amount;
		addTradeLog(amount, "입금", balance);
	}
	
	public void withdraw(int amount)
	{
		if(withdrawMethod.withdraw(balance ,amount) == true)
		{
			balance -= amount;
			addTradeLog(-1*amount, "출금", balance);
		}
	}
	
	public int calculateInterest()
	{
		return calculateInterestMethod.calculateInterest(balance);
	}
	
	public void addTradeLog(int tradeAmount, String tradeType, int currentBalance)
	{
		tradeLogs.add(new TradeLog(tradeAmount, tradeType, currentBalance));
	}
	
	public ArrayList<TradeLog> getTradeLogs()
	{
		return tradeLogs;
	}
	
}