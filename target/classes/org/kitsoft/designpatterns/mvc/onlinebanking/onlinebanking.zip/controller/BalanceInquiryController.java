package org.kitsoft.designpatterns.mvc.onlinebanking.controller;

public class BalanceInquiryController implements TransactionControllerImp {
	private AccountAccessManager aam;
	
	public BalanceInquiryController(AccountAccessManager aam) {
		this.aam = aam;
	}
	
	public void execute() {
		aam.inquireBalance();
	}
}
