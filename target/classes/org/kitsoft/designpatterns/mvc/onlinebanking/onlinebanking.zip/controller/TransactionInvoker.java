package org.kitsoft.designpatterns.mvc.onlinebanking.controller;

public class TransactionInvoker {
	private TransactionControllerImp transactionController;
	
	public TransactionInvoker(TransactionControllerImp tci) {
		this.transactionController = tci;
	}
	
	public void order() { 
		transactionController.execute();
	}
}
