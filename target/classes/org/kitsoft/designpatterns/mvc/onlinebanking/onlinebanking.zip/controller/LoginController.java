package org.kitsoft.designpatterns.mvc.onlinebanking.controller;

public class LoginController {

}
