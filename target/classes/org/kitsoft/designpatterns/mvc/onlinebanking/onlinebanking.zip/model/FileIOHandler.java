package org.kitsoft.designpatterns.mvc.onlinebanking.model;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.ArrayList;

public class FileIOHandler {
	private final String CUSTOMER_FILEPATH = "CustomerInfo.txt";
	private final String ACCOUNT_FILEPATH = "AccountInfo.txt";

	private ArrayList<CustomerInfo> customerList;
	
	public void createCustomer(CustomerInfo c) {
		customerList = (ArrayList<CustomerInfo>)readCustomer();
		
		if(customerList == null) {
			customerList = new ArrayList<CustomerInfo>();
		}

		customerList.add(c);
		writeCustomer();
	}
	
	public boolean findCustomer(String id) {
		customerList = (ArrayList)readCustomer();
		
		for(CustomerInfo c : customerList) {
			if(c.confirmID(id)) {
				return true;
			}
		}
		
		return false;
	}

	public Object readCustomer() {
		Object o = null;
		
		try {
			FileInputStream fis = new FileInputStream(CUSTOMER_FILEPATH);
			BufferedInputStream bis = new BufferedInputStream(fis); 
			ObjectInputStream input = new ObjectInputStream(bis);	
			
			o = input.readObject();

			input.close();
			
			return o;
		}
		catch(ClassNotFoundException e) {
			e.printStackTrace();
		}
		catch(NullPointerException e) {
			e.printStackTrace();
		}
		catch(IOException e) {
			e.printStackTrace();
		}
		
		return null;
	}
	
	public void writeCustomer() {		
		try {
			FileOutputStream fos = new FileOutputStream(CUSTOMER_FILEPATH);
			BufferedOutputStream bos = new BufferedOutputStream(fos); 
			ObjectOutputStream output = new ObjectOutputStream(bos);
			
			output.writeObject(customerList);

			output.close();
		}
		catch(NullPointerException e) {
			e.printStackTrace();
		}
		catch(IOException e) {
			e.printStackTrace();
		}
	}
}
