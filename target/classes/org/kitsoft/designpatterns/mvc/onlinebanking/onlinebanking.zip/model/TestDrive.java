﻿package org.kitsoft.designpatterns.mvc.onlinebanking.model;

import java.io.*;
import java.util.ArrayList;

public class TestDrive 
{
	public static void main(String[] args)
	{
		FileIOHandler io = new FileIOHandler();
		
		CustomerInfo c1 = new CustomerInfo("규호", "1", "1234");
//		io.createCustomer(c1);
		
		boolean isOk = io.findCustomer("1");
		System.out.println(isOk);
	}
	
	public static void a() //객체쓰기
	{
		try
		{
			FileOutputStream fos = new FileOutputStream("test.txt");
			BufferedOutputStream bos = new BufferedOutputStream(fos); 
			ObjectOutputStream out = new ObjectOutputStream(bos);

			Account a = new FreeAccount(); 			//생성시 자동으로 0원
			Account b = new MinusAccount(10000); 	//신용한도 10000원
			
			a.deposit(10000);
			b.deposit(10000);
			
			ArrayList<Account> accounts = new ArrayList<Account>();
			
			accounts.add(a);
			accounts.add(b);
			
			CustomerInfo ci = new CustomerInfo("김규호", "kyuho6942","1234");
			ci.addAccount(a);
			ci.addAccount(b);
			out.writeObject(ci);
			out.close();
			System.out.println("직렬화 완료");
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
	}
	
	public static void b() //객체 읽기
	{
		try
		{
			FileInputStream fis = new FileInputStream("test.txt");
			BufferedInputStream bis = new BufferedInputStream(fis); 
			ObjectInputStream in = new ObjectInputStream(bis);

			CustomerInfo ci = (CustomerInfo) in.readObject();
			
			ArrayList<Account> accounts = ci.getAccounts();
			
			
			ci.info();
			
			for(Account a: accounts)
			{
				System.out.println("Account의 이자:" +a.calculateInterest());
				System.out.println("Account의 잔고:" +a.getBalance());
				System.out.println("/////////////////////거래내역/////////////////////");
				for(TradeLog log : a.getTradeLogs())
				{
					log.printLog();
				}
			}
			
			in.close();
			System.out.println("역직렬화 완료");
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
	}
}
