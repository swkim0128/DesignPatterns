﻿package org.kitsoft.designpatterns.mvc.onlinebanking.model;

public class DataAccessManager {
	private static class Holder {
		private static DataAccessManager dataAccessManager = new DataAccessManager();		
	}
	
	private DataAccessManager() {
		
	}

	public static DataAccessManager getInstance() {		
		return Holder.dataAccessManager;
	}
}