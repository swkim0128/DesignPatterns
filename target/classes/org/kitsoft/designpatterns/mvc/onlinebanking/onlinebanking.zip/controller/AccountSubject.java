package org.kitsoft.designpatterns.mvc.onlinebanking.controller;

public interface AccountSubject {
	public void registerObserver(AccountObserver o);
	public void removeObserver(AccountObserver o);
	public void notifyObserver();
}
