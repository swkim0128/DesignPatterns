package org.kitsoft.designpatterns.mvc.onlinebanking.view;

import javax.swing.JPanel;
import java.awt.BorderLayout;
import javax.swing.JButton;
import javax.swing.JComponent;
import javax.swing.JFrame;
import javax.swing.JMenuBar;

import java.awt.GridLayout;

import javax.swing.border.EmptyBorder;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class AccountSelectPanel extends JPanel {
	
	private JFrame superFrame;
	private JPanel accountSelectedPanel;
	private JPanel accountCreatePanel;
	
	/**
	 * Create the panel.
	 */
	public AccountSelectPanel(JFrame superFrame) {
		super();
		this.superFrame = superFrame;
		accountSelectedPanel = new AccountSelectedPanel(superFrame);
		accountCreatePanel = new AccountCreatePanel(superFrame);
				
		initialize();
	}
	
	private void initialize() {
		setLayout(new BorderLayout(0, 0));
		
		JPanel panel = new JPanel();
		panel.setBorder(new EmptyBorder(80, 80, 80, 80));
		add(panel, BorderLayout.CENTER);
		
		JButton accountSelectButton = new JButton("계좌 선택");
		accountSelectButton.setBounds(125, 100, 400, 100);
		accountSelectButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				onClickedAccountSelectButton();
			}
		});
		panel.setLayout(null);
		panel.add(accountSelectButton);
		
		JButton accountCreateButton = new JButton("계좌 생성");
		accountCreateButton.setBounds(125, 232, 400, 100);
		accountCreateButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				onClickedAccountCreateButton();
			}
		});
		panel.add(accountCreateButton);
		
	}

	private void onClickedAccountSelectButton() {
		JMenuBar menu = superFrame.getJMenuBar();
		((MenuBar) menu).setBackPanel(this);
		((MenuBar) menu).setEnabledBackMenuItem(true);
		
		superFrame.getContentPane().removeAll();
		superFrame.getContentPane().add(accountSelectedPanel, BorderLayout.CENTER);
		superFrame.revalidate();
		superFrame.repaint();
	}
	
	private void onClickedAccountCreateButton() {
		JMenuBar menu = superFrame.getJMenuBar();
		((MenuBar) menu).setBackPanel(this);
		((MenuBar) menu).setEnabledBackMenuItem(true);
		
		superFrame.getContentPane().removeAll();
		superFrame.getContentPane().add(accountCreatePanel, BorderLayout.CENTER);
		superFrame.revalidate();
		superFrame.repaint();
	}
}
