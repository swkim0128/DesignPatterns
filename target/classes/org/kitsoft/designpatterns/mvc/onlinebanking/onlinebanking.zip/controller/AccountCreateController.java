package org.kitsoft.designpatterns.mvc.onlinebanking.controller;

public class AccountCreateController {
	public void createAccount() {
		
	}
}
