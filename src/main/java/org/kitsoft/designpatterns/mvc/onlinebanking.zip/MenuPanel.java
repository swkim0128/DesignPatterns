package org.kitsoft.designpatterns.mvc.onlinebanking;

import javax.swing.JPanel;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.JMenu;

public class MenuPanel extends JPanel {

	private JMenuItem accountChangeMenuItem;
	/**
	 * Create the panel.
	 */
	public MenuPanel() {
		
		JMenuBar menuBar = new JMenuBar();
		add(menuBar);
		
		JMenu accountMenu = new JMenu("계정");
		menuBar.add(accountMenu);
		
		JMenuItem logoutMenuItem = new JMenuItem("로그아웃");
		accountMenu.add(logoutMenuItem);
		
		accountChangeMenuItem = new JMenuItem("계좌변경");
		accountChangeMenuItem.setEnabled(false);
		accountMenu.add(accountChangeMenuItem);

	}

	public void setEnableAccountChangeMenu(boolean flag) {
		accountChangeMenuItem.setEnabled(flag);
	}
}
