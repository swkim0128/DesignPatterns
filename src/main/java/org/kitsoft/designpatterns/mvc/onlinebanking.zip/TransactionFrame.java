package org.kitsoft.designpatterns.mvc.onlinebanking;

import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.BoxLayout;
import javax.swing.JLabel;
import javax.swing.SwingConstants;
import java.awt.GridLayout;
import java.awt.FlowLayout;
import javax.swing.JButton;
import javax.swing.UIManager;

public class TransactionFrame extends JFrame {

	private JPanel contentPane;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					TransactionFrame frame = new TransactionFrame();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public TransactionFrame() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 450, 300);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(new BoxLayout(contentPane, BoxLayout.Y_AXIS));
		
		JLabel currentAccountLabel = new JLabel("New label");
		currentAccountLabel.setAlignmentX(0.5f);
		contentPane.add(currentAccountLabel);
		currentAccountLabel.setHorizontalAlignment(SwingConstants.CENTER);
		
		JPanel panel_1 = new JPanel();
		panel_1.setBorder(new EmptyBorder(20, 20, 20, 20));
		contentPane.add(panel_1);
		panel_1.setLayout(new GridLayout(2, 3, 10, 10));
		
		JButton depositButton = new JButton("입금");
		depositButton.setBackground(UIManager.getColor("Button.background"));
		//depositButton.setBorderPainted(false);
		depositButton.setFocusPainted(false);
		depositButton.setContentAreaFilled(false);
		panel_1.add(depositButton);
		
		JButton withdrawButton = new JButton("출금");
		withdrawButton.setFocusPainted(false);
		withdrawButton.setContentAreaFilled(false);
		panel_1.add(withdrawButton);
		
		JButton transactionInquireButton = new JButton("거래내역조회");
		transactionInquireButton.setFocusPainted(false);
		transactionInquireButton.setContentAreaFilled(false);
		panel_1.add(transactionInquireButton);
		
		JButton balanceInquireButton = new JButton("잔액조회");
		balanceInquireButton.setFocusPainted(false);
		balanceInquireButton.setContentAreaFilled(false);
		panel_1.add(balanceInquireButton);
		
		JButton transferButton = new JButton("계좌이체");
		transferButton.setFocusPainted(false);
		transferButton.setContentAreaFilled(false);
		panel_1.add(transferButton);
	}

}
