package org.kitsoft.designpatterns.mvc.onlinebanking;

import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JButton;
import javax.swing.BoxLayout;
import java.awt.GridLayout;

public class LoginnedFrame extends JFrame {

	private JPanel contentPane;
	private MenuPanel menu;
	
	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					LoginnedFrame frame = new LoginnedFrame();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public LoginnedFrame() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 450, 300);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(80, 80, 80, 80));
		setContentPane(contentPane);
		contentPane.setLayout(new BorderLayout(0, 0));
		
		menu = new MenuPanel();
		menu.setEnableAccountChangeMenu(false);
		contentPane.add(menu, BorderLayout.NORTH);
		
		JPanel panel = new JPanel();
		panel.setBorder(new EmptyBorder(10, 10, 10, 10));
		contentPane.add(panel, BorderLayout.CENTER);
		panel.setLayout(new GridLayout(2, 1, 0, 10));
		
		JButton accountSelectButton = new JButton("계좌선택");
		accountSelectButton.setAlignmentX(0.5f);
		panel.add(accountSelectButton);
		
		JButton accountCreateButton = new JButton("계좌개설");
		accountCreateButton.setAlignmentX(0.5f);
		panel.add(accountCreateButton);
	}

}
