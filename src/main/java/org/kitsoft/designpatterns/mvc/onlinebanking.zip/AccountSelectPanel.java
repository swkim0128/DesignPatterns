package org.kitsoft.designpatterns.mvc.onlinebanking;

import javax.swing.JPanel;
import java.awt.BorderLayout;
import javax.swing.JTable;
import javax.swing.JScrollBar;
import javax.swing.ListSelectionModel;
import javax.swing.JScrollPane;

public class AccountSelectPanel extends JPanel {
	private JTable table;

	/**
	 * Create the panel.
	 */
	public AccountSelectPanel() {
		setLayout(new BorderLayout(0, 0));
		
		JPanel panel = new JPanel();
		add(panel, BorderLayout.CENTER);
		
		String header[] = { "게좌번호", "은행" };
		String contents[][] = { 
				{"abc", "신한"},
				{"bc", "농협" },
				{"bc", "농협" },
				{"bc", "농협" },
				{"bc", "농협" },
				{"bc", "농협" },
				{"bc", "농협" },
				{"bc", "농협" },
				{"bc", "농협" },
				{"bc", "농협" },
				{"bc", "농협" },
				{"abc", "신한"},
		};
		
		table = new JTable(contents, header);
		table.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
				
		JScrollPane scrollPane = new JScrollPane(table);
		panel.add(scrollPane);
		
		JPanel panel_1 = new JPanel();
		add(panel_1, BorderLayout.SOUTH);

	}

}
